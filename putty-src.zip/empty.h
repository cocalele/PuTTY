/* Empty file touched by automake makefile to force rebuild of version.o */
